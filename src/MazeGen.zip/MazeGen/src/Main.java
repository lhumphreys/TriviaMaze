import java.util.ArrayList;


public class Main
{
	public static void main(String[] args)
	{
		Maze maze = MazeGen.generate(25);
		maze.printMaze();
	}
}
