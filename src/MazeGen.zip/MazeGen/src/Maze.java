import java.util.Iterator;

public class Maze
{
	private Block[][] blocks;
	private int[] end;
	private int[] start;
	private int[] playerPosition;
	private int numMoves;

	public Maze(Block[][] blocks)
	{
		this.blocks = blocks;
	}

	public boolean move(int[] coordinates)
	{
		// ONLY HORIZONTAL AND VERTICAL COORDINATES!
		this.playerPosition = coordinates;
		if (coordinates == end)
		{
			return true;
		}
		return false;
	}

	public int[] getStart()
	{
		return start;
	}

	public void setStart(int[] start)
	{
		this.start = start;
	}

	public int[] getEnd()
	{
		return end;
	}

	public void setEnd(int[] end)
	{
		this.end = end;
	}

	public void printMaze()
	{
		for (int i = 0; i < blocks.length; i++)
		{
			String line = "";
			for (int j = 0; j < blocks.length; j++)
			{
				line += blocks[i][j].toString() + " ";
			}
			System.out.println(line);
		}
	}
}
